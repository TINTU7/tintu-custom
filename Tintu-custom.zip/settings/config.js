module.exports = {
    TOKEN: "",
    ownerID: ["1004206704994566164", ""],
    botInvite: "",
    supportServer: "",
    status: 'Custom BoT Coming Soon..',
    prefix: 'd',
    language: "en",
    embedColor: "00fbff",
    errorLog: "1197540287535390770",
    guildlogs:"1197540287535390770",
  }